delete

from payment

where customer_id = 4;

delete

from rental

where customer_id = 4;
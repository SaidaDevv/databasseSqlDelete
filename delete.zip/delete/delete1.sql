
delete
from payment
where rental_id in

      (select rental_id from rental where inventory_id in ((select inventory_id from inventory where film_id = 5)));

delete
from rental
where inventory_id in


      (select inventory_id from inventory where film_id = 4);


delete
from inventory

where film_id = 53;